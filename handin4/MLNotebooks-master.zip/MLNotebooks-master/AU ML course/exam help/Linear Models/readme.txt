Read the files in the following order:

1. Perceptron
2. LinearRegression
3. LogisticRegression
4. Feature Transform

It is assumed you know of the Supervised Learning problem. Videos that supplement the notebooks will be added ASAP. 
