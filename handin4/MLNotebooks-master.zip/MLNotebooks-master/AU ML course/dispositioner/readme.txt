If I get time I'll make IPython Notebook for each exam topic with relevant derivations theory and relevant code experiments. 

1. Linear Regression
- The Supervised Learning Problem
- Perceptron Learning Algorithm
- Linear Regression
- Logistic Regression
- Gradient Descent for non-convex objectives
- Feature Transforms

2. Learning Theory
- The Supervised Learning Problem (E_in + E_out)
- The Hoeffding Bound
- Definitions of VC dimensions
- Bias Variance tradeof 

3. Neural Networks
- The Supervised Learning Problem
- Feed Forward Neural Networks
- Computing derivatives and backpropagation
- Gradient Descent
- Convolutional Neural Networks
- AutoEncoders

4. Support Vector Machines
- The Supervised Learning Problem (which hyperplane is the best)
- Maximize margins 
- Rewrite problem, math math math
- Kernel Trick (Mercer's theorem + examples, PSD)

5. Decision Trees (Bagging / Boosting)
- The Supervised Learning Problem
- Bias/Variance tradeof
- Boosting: DT + adaboost
- Bagging: ??

6. Hidden Markov Models
- Motivation, i.i.d., markov assumption, latent states
- HMM, joint prob, decoding (viterbi / posterior)
- Proof of recursions
- Computing w, alpha and beta
- Training by counting
- Training without Z (viterbi training / baum welch)

7. Unsupervised Learning
- The (Un)Supervised Learning Problem (loosing the labels)
- k-means / k-mediods
- Expectation maximization
- F1
- silhouette
- ...

8. Reinforcement Learning
- The Reinforcement Learning Problem
- Dynamic Programming
- ..
- Q-learning
- Sarsha
...


